import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;
public class Users
{
	public static WebDriver driver;
	public static String ScreenshotName;

	@BeforeMethod
	public void setup()throws Exception{
		System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\Java\\jdk1.8.0_231\\lib\\chromedriver_win32_2.4\\chromedriver.exe");
    	// declaration and instantiation of objects/variables
        driver = new ChromeDriver();
        driver.manage().timeouts().pageLoadTimeout(10000000, TimeUnit.SECONDS);
       driver.manage().timeouts().implicitlyWait(12000000, TimeUnit.SECONDS);
        driver.manage().window().maximize();
        driver.manage().deleteAllCookies();
        driver.get("http://localhost/wordpress/wp-login.php");
        WebElement username = driver.findElement(By.id("user_login"));
        username.clear();
        username.sendKeys("wordpress"); 
        WebElement password = driver.findElement(By.id("user_pass"));
        password.clear();
        password.sendKeys("wordpress");
        driver.findElement(By.id("wp-submit")).click();   
        driver.get("http://localhost/wordpress/wp-admin/");
       // Screenshots.takeSnapShot(driver, "ScreenshotName");
	}
	@Test(priority =1) 
	  // Valid Test case 1
	  public void allUsers() throws Exception
	  {		  
		 driver.findElement(By.linkText("Users")).click();
		 driver.findElement(By.linkText("All Users")).click();
		  String expected = driver.getCurrentUrl();
		  System.out.println(expected);
		  String actual = "http://localhost/wordpress/wp-admin/users.php";
		  Assert.assertEquals(expected, actual);
		  Userscreenshot.takeSnapShot(driver,"All Users");
		  driver.close();
	  }
	@Test(priority =2) 
	  // Valid Test case 2
	  public void addNew() throws Exception
	  {		  
		 driver.findElement(By.linkText("Users")).click();
		 driver.findElement(By.linkText("Add New")).click();
		  String expected = driver.getCurrentUrl();
		  System.out.println(expected);
		  String actual = "http://localhost/wordpress/wp-admin/user-new.php";
		  Assert.assertEquals(expected, actual);	
		  Userscreenshot.takeSnapShot(driver,"Add New User");
		  driver.close();
	  }
	@Test(priority =3) 
	  // Valid Test case 3
	  public void yourProfile() throws Exception
	  {		  
		 driver.findElement(By.linkText("Users")).click();
		 driver.findElement(By.linkText("Your Profile")).click();
		  String expected = driver.getCurrentUrl();
		  System.out.println(expected);
		  String actual = "http://localhost/wordpress/wp-admin/profile.php";
		  Assert.assertEquals(expected, actual);	
		  Userscreenshot.takeSnapShot(driver,"Your Profile");
		  driver.close();
	  }
	@Test(priority =4) 
	  // InValid Test case 1
	  public void searchUserName() throws Exception
	  {		  
		driver.findElement(By.linkText("Users")).click();
		driver.findElement(By.linkText("All Users")).click();
		WebElement user = driver.findElement(By.id("user-search-input"));
        user.clear();
        user.sendKeys("Murdula");
		driver.findElement(By.linkText("Search Users")).click();		 
		String expected = driver.findElement(By.className("subtitle")).getText();
		System.out.println(expected);
		String actual = "Search results not found";
		Assert.assertEquals(expected, actual);	
		Userscreenshot.takeSnapShot(driver,"Search User Name");
		driver.close();
	  }
	@Test(priority =5) 
	  // InValid Test case 2
	  public void applyButton() throws Exception
	  {
		driver.findElement(By.linkText("Users")).click();
		driver.findElement(By.linkText("All Users")).click();
		WebElement apply = driver.findElement(By.id("doaction2"));
		apply.click();			 
		String expected = driver.getTitle();
		System.out.println(expected);
		String actual = "Please select one user.";
		Assert.assertEquals(expected, actual);	
		Userscreenshot.takeSnapShot(driver,"Apply Button");
		driver.close();
	  }
	@Test(priority =6) 
	  // InValid Test case 2
	  public void search() throws Exception
	  {
		driver.findElement(By.linkText("Users")).click();
		driver.findElement(By.linkText("All Users")).click();
		WebElement user = driver.findElement(By.id("user-search-input"));
        user.clear();
        user.sendKeys("");
		driver.findElement(By.linkText("Search Users")).click();		 
		String expected = driver.findElement(By.className("subtitle")).getText();
		System.out.println(expected);
		String actual = "user name must be typed in the Search box";
		Assert.assertEquals(expected, actual);	
		Userscreenshot.takeSnapShot(driver,"Search Field");
		driver.close();
	  }
}//End of class