import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;
@Test
public class Dashboard
{
	public static WebDriver driver;
	public static String ScreenshotName;

	@BeforeMethod
	public void setup()throws Exception{
		System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\Java\\jdk1.8.0_231\\lib\\chromedriver_win32_2.4\\chromedriver.exe");
    	// declaration and instantiation of objects/variables
        driver = new ChromeDriver();
        driver.manage().timeouts().pageLoadTimeout(1000000, TimeUnit.SECONDS);
       driver.manage().timeouts().implicitlyWait(1200000, TimeUnit.SECONDS);
        driver.manage().window().maximize();
        driver.manage().deleteAllCookies();
        driver.get("http://localhost/wordpress/wp-login.php");
        WebElement username = driver.findElement(By.id("user_login"));
        username.clear();
        username.sendKeys("wordpress"); 
        WebElement password = driver.findElement(By.id("user_pass"));
        password.clear();
        password.sendKeys("wordpress");
        driver.findElement(By.id("wp-submit")).click();   
        driver.get("http://localhost/wordpress/wp-admin/");
       // Screenshots.takeSnapShot(driver, "ScreenshotName");
	}
		 	  
	 @Test(priority =2) 
	  // Valid Test case 1
	  public void customisePageButton() throws Exception
	  {		  
		 driver.findElement(By.linkText("Customize Your Site")).click();
		  String expected = driver.getCurrentUrl();
		  System.out.println(expected);
		  String actual = "http://localhost/wordpress/wp-admin/customize.php";
		  Assert.assertEquals(expected, actual);	
		  Screenshots.takeSnapShot(driver,"CustomisePageButton");
		 driver.close();
	  }
	 
	 @Test(priority =3) 
	  //Valid Test case 2
	  public void writeBlogText() throws Exception
	  {		 
		 driver.findElement(By.linkText("Write your first blog post")).click();
		  String expected = driver.getCurrentUrl();
		  System.out.println(expected);
		  String actual = "http://localhost/wordpress/wp-admin/post-new.php";
		  Assert.assertEquals(expected, actual);	
		  Screenshots.takeSnapShot(driver,"Write Blog Text");
		  driver.close();
	  }	 
	 
	 @Test(priority =3) 
	  //Valid Test case 3
	  public void changeThemeText() throws Exception
	  {		 
		 driver.findElement(By.linkText("change your theme completely")).click();
		  String expected = driver.getCurrentUrl();
		  System.out.println(expected);
		  String actual = "http://localhost/wordpress/wp-admin/customize.php?autofocus[panel]=themes";
		  Assert.assertEquals(expected, actual);	
		  Screenshots.takeSnapShot(driver,"Change Theme Text");
		  driver.close();
	  }	 
	 
	// Invalid Test case 1
		@Test(priority =1)
		  public void VerifyDashboardTitle() throws Exception
		  {			         
	          String title = driver.getTitle();
	      	  System.out.println("the page title is: "+title);
	      	  Assert.assertEquals(title, "Dashboard");
	      	Screenshots.takeSnapShot(driver,"Verify dashboard Title");
	      	  driver.close();
		  }
		
	 @Test(priority =4) 
	  //Invalid Test case 2
	  public void addAboutPageLink() throws Exception
	  {		 
		 driver.findElement(By.linkText("Add an About page")).click();
		  String expected = driver.getCurrentUrl();
		  System.out.println(expected);
		  String actual = "http://localhost/wordpress/wp-admin/post-new.php";
		  Assert.assertEquals(expected, actual);
		  Screenshots.takeSnapShot(driver,"Add About Page Link");
		  driver.close();
	  }
	 
	 @Test(priority =5) 
	  //InValid Test case 3
	  public void updatesDashboard() throws Exception
	  {		 
		 driver.findElement(By.linkText("Updates")).click();
		  String expected = driver.getTitle();
		  System.out.println(expected);
		  Assert.assertEquals(expected, "Wordpress Updates");	
		  Screenshots.takeSnapShot(driver,"Update Dashboard");
		  driver.close();
	  }
	 
	 
	 
}//End of class