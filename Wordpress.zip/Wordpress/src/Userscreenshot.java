import java.io.File;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
public class Userscreenshot extends Users
{
	 public static void takeSnapShot(WebDriver webdriver,String ScreenshotName) throws Exception{

	        try
			{
				//Convert web driver object to TakeScreenshot

				TakesScreenshot scrShot =((TakesScreenshot)webdriver);

				//Call getScreenshotAs method to create image file
					scrShot.getScreenshotAs(OutputType.FILE);
				        File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);

				    //Move image file to new destination

				      //  File DestFile=new File(ScreenshotName);

				        //Copy file at destination
				        FileUtils.copyFile(SrcFile,new File("./Screenshot/"+ScreenshotName+" .png"));
				       // FileUtils.copyFile(SrcFile,new File("./Screenshot"+ScreenshotName+" .png"));
			} catch (Exception e)
			{

			}
	 }
}
//End of class