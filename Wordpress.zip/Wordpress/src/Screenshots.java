
import java.io.File;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Screenshots extends Dashboard{

   
    //public void TakeScreenShot(WebDriver driver,String Screenshot) throws Exception{

		//WebDriver driver ;
	//	System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\Java\\jdk1.8.0_231\\lib\\chromedriver_win32_2.4\\chromedriver.exe");
    	//driver = new ChromeDriver();
        //goto url

        //driver.get("http:\\localhost\\index.php");

        //Call take screenshot function

        //this.takeSnapShot(driver, "c://test.png") ;     

    
    /**

     * This function will take screenshot

     * @param webdriver

     * @param fileWithPath

     * @throws Exception

     */

    public static void takeSnapShot(WebDriver webdriver,String ScreenshotName) throws Exception{

        try
		{
			//Convert web driver object to TakeScreenshot

			TakesScreenshot scrShot =((TakesScreenshot)webdriver);

			//Call getScreenshotAs method to create image file
				scrShot.getScreenshotAs(OutputType.FILE);
			        File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);

			    //Move image file to new destination

			      //  File DestFile=new File(ScreenshotName);

			        //Copy file at destination
			        FileUtils.copyFile(SrcFile,new File("./Screenshot/"+ScreenshotName+" .png"));
			       // FileUtils.copyFile(SrcFile,new File("./Screenshot"+ScreenshotName+" .png"));
		} catch (Exception e)
		{

		}

    }

}